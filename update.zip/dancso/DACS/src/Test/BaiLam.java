/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Test;

import View.DangNhap;

/**
 *
 * @author phamn
 */
public class BaiLam {
    public static void main(String[] args) {
          DangNhap bin =new DangNhap();
          bin.setVisible(true);
          bin.setDefaultCloseOperation(0);
    }
    
}
