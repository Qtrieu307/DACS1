package service;

import java.util.List;

import Model.Book_Model;
import Model.TheMuon;

public interface Thongkeservice {
   public List<TheMuon> getList();
   public List<Book_Model> getListSach();
}

